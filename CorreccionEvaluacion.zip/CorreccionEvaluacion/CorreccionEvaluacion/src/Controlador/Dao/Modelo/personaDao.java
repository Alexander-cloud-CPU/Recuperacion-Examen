/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.Dao.Modelo;

import Controlador.Dao.DaoImplement;
import Controlador.TDA.ListaDinamica.ListaDinamica;
import Modelo.Tramite;
import java.util.Random;

/**
 *
 * @author Alexander 
 */
public class personaDao extends DaoImplement<Tramite>{
    private ListaDinamica<Tramite> ListaPersonas = new ListaDinamica<>();
    private Tramite persona;
    
    public personaDao(){
        super (Tramite.class);
    }
    
    public ListaDinamica<Tramite> getListaPersonas() {
        ListaPersonas = all();
        return ListaPersonas;
    }

    public void setListaPersonas(ListaDinamica<Tramite> ListaPersonas) {
        this.ListaPersonas = ListaPersonas;
    }

    public Tramite getPersona() {
        if(persona == null){
            persona = new Tramite();
        }
        return persona;
    }

    public void setPersona(Tramite persona) {
        this.persona = persona;
    }
    
    public Boolean Persist(){
        persona.setIdPersona(all().getLongitud()+1);
        return Persist(persona);
    }
 
    
}
