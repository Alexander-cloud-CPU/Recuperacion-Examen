/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.Dao.Modelo;

import Controlador.Dao.DaoImplement;
import Controlador.TDA.ListaDinamica.ListaDinamica;
import Modelo.Simulacion;

/**
 *
 * @author Victor
 */
public class simulacionDao extends DaoImplement<Simulacion>{
    private ListaDinamica<Simulacion> ListaSimulacion = new ListaDinamica<>();
    private Simulacion simulacion;
    
    public simulacionDao(){
        super (Simulacion.class);
    }
    
    public ListaDinamica<Simulacion> getListaSimulacion() {
        ListaSimulacion = all();
        return ListaSimulacion;
    }

    public void setListaSimulacion(ListaDinamica<Simulacion> ListaSimulacion) {
        this.ListaSimulacion = ListaSimulacion;
    }

    public Simulacion getSimulacion() {
        if(simulacion == null){
            simulacion = new Simulacion();
        }
        return simulacion;
    }

    public void setSimulacion(Simulacion simulacion) {
        this.simulacion = simulacion;
    }

    public Boolean Persist() {
        simulacion.setId(all().getLongitud() + 1);
        return Persist(simulacion);
    }
}
