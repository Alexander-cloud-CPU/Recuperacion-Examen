/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

import Controlador.Dao.Modelo.personaDao;
import Controlador.Dao.Modelo.simulacionDao;
import Controlador.TDA.ListaDinamica.ListaDinamica;
import Controlador.Tda.listas.Exepciones.ListaVacia;
import Modelo.Tramite;
import Vista.Tabla.ModeloTabla1;
import Vista.Tabla.ModeloTabla;
import Vista.Tabla.ModeloTabla3;
import Vista.Tabla.TablaSimulacion;
import java.util.Random;
import javax.swing.JOptionPane;

/**
 *
 * @author Alexander 
 */
public class FrmSimulacion extends javax.swing.JFrame {
    personaDao personalesDao = new personaDao();
    simulacionDao simulacionDao = new simulacionDao();
    ModeloTabla1 mtp = new ModeloTabla1();
    ModeloTabla mtp2 = new ModeloTabla();
    ModeloTabla3 mtp3 = new ModeloTabla3();
    TablaSimulacion mts = new TablaSimulacion();

    /**
     * Creates new form VistaPrincipal
     */
    public FrmSimulacion() {
        initComponents();
        this.setLocationRelativeTo(null);
    }
    
    private void CargarSimulacion() throws ListaVacia {
        mts.setPersonasTabla(simulacionDao.getListaSimulacion());
        tblSimulacion.setModel(mts);
        tblSimulacion.updateUI();
    }

    private void CargarPrimerTabla() throws ListaVacia {
        int numero = Integer.parseInt(txtTramites.getText());
        mtp.setPersonasTabla(tramitegenerado(numero));
        tblVentana1.setModel(mtp);
        tblVentana1.updateUI();
    }

    private void CargarSegunda() throws ListaVacia {
        int numero2 = Integer.parseInt(txtTramites.getText());
        mtp2.setPersonasTabla(tramitegenerado(numero2));
        tblVentana2.setModel(mtp2);
        tblVentana2.updateUI();
    }
    
    private void CargarTercer() throws ListaVacia {
        int numero3 = Integer.parseInt(txtTramites.getText());
        mtp3.setPersonasTabla(tramitegenerado(numero3));
        tblVentana3.setModel(mtp3);
        tblVentana3.updateUI();
    }

    public Tramite aleatorio() {
        Random random = new Random();
        int tramiteejecutar = random.nextInt(4);
        try {
            for (int i = 0; i < personalesDao.getListaPersonas().getLongitud(); i++) {
                personalesDao.getListaPersonas().getInfo(i);
            }
        } catch (Exception e) {
        }
        switch (tramiteejecutar) {
            case 0:
                return new Tramite(null, "Cambio de clave", 4);
            case 1:
                return new Tramite(null, "Actualizacion de datos", 7);
            case 2:
                return new Tramite(null, "Asignacion afiliados", 15);
            case 3:
                return new Tramite(null, "Recuperacion de clave", 3);
            default:
                return null;
        }
    }

    public ListaDinamica<Tramite> tramitegenerado(int cantidad) throws ListaVacia {
        ListaDinamica<Tramite> tramites = new ListaDinamica<>();
        for (int i = 0; i < cantidad; i++) {
            Tramite tramite = aleatorio();
            tramites.Agregar(tramite);
        }
        return tramites;
    }
    
    private void Ventanilla1() {
        int fila = tblVentana1.getSelectedRow();
        if(fila < 0){
            JOptionPane.showMessageDialog(null, "Escoga un registro");
        }
        else{
            try {
                personalesDao.setPersona(mtp.getPersonasTabla().getInfo(fila));
                System.out.println(""+personalesDao.getPersona());
            } 
            catch (Exception e) {
            }
        }
    }
    
    private void Guardar() throws ListaVacia {
        int filas = tblVentana1.getSelectedRow();
        Integer dg = (Integer) tblVentana1.getValueAt(filas, 0);
        String sasddasd = tblVentana1.getValueAt(filas, 1).toString();
        Integer za = (Integer) tblVentana1.getValueAt(filas, 2);
        Tramite g = new Tramite(dg, sasddasd, za);
        Integer IdPersona = personalesDao.getListaPersonas().getLongitud() + 1;
        Integer IdPersonSa = simulacionDao.getListaSimulacion().getLongitud() + 1;
        simulacionDao.getSimulacion().setId(IdPersona);
        simulacionDao.getSimulacion().setNumeroPersonas(IdPersonSa);
        simulacionDao.getSimulacion().setTiempoFinal(za);
        simulacionDao.getSimulacion().setPersona(g);
        if (simulacionDao.Persist()) {
            JOptionPane.showMessageDialog(null, "Atendido", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "No atendido", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void Ventanilla2() {
        int fila = tblVentana2.getSelectedRow();
        if(fila < 0){
            JOptionPane.showMessageDialog(null, "Escoga un registro");
        }
        else{
            try {
                personalesDao.setPersona(mtp.getPersonasTabla().getInfo(fila));
                System.out.println(""+personalesDao.getPersona());
            } 
            catch (Exception e) {
            }
        }
    }
    
    private void Guardar2() throws ListaVacia {
        int filas = tblVentana2.getSelectedRow();
        Integer dg = (Integer) tblVentana2.getValueAt(filas, 0);
        String sasddasd = tblVentana2.getValueAt(filas, 1).toString();
        Integer za = (Integer) tblVentana2.getValueAt(filas, 2);
        Tramite g = new Tramite(dg, sasddasd, za);
        Integer IdPersona = personalesDao.getListaPersonas().getLongitud() + 1;
        Integer IdPersonSa = simulacionDao.getListaSimulacion().getLongitud() + 1;
        simulacionDao.getSimulacion().setId(IdPersona);
        simulacionDao.getSimulacion().setNumeroPersonas(IdPersonSa);
        simulacionDao.getSimulacion().setTiempoFinal(za);
        simulacionDao.getSimulacion().setPersona(g);
        if (simulacionDao.Persist()) {
            JOptionPane.showMessageDialog(null, "Atendido", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "No atendido", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
        }
    }
    
    private void Ventanilla3() {
        int fila = tblVentana3.getSelectedRow();
        if(fila < 0){
            JOptionPane.showMessageDialog(null, "Escoga un registro");
        }
        else{
            try {
                personalesDao.setPersona(mtp.getPersonasTabla().getInfo(fila));
                System.out.println(""+personalesDao.getPersona());
            } 
            catch (Exception e) {
            }
        }
    }
    
    private void Guardar3() throws ListaVacia {
        int filas = tblVentana3.getSelectedRow();
        Integer dg = (Integer) tblVentana3.getValueAt(filas, 0);
        String sasddasd = tblVentana3.getValueAt(filas, 1).toString();
        Integer za = (Integer) tblVentana3.getValueAt(filas, 2);
        Tramite g = new Tramite(dg, sasddasd, za);
        Integer IdPersona = personalesDao.getListaPersonas().getLongitud() + 1;
        Integer IdPersonSa = simulacionDao.getListaSimulacion().getLongitud() + 1;
        simulacionDao.getSimulacion().setId(IdPersona);
        simulacionDao.getSimulacion().setNumeroPersonas(IdPersonSa);
        simulacionDao.getSimulacion().setTiempoFinal(za);
        simulacionDao.getSimulacion().setPersona(g);
        if (simulacionDao.Persist()) {
            JOptionPane.showMessageDialog(null, "Atendido", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "No atendido", "INFORMACION", JOptionPane.INFORMATION_MESSAGE);
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtTramites = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblVentana1 = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblVentana2 = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblVentana3 = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblSimulacion = new javax.swing.JTable();
        ventana1 = new javax.swing.JButton();
        total = new javax.swing.JButton();
        ventana2 = new javax.swing.JButton();
        ventana3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 204, 255));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("Tramites");

        jButton1.setBackground(new java.awt.Color(0, 204, 255));
        jButton1.setFont(new java.awt.Font("OCR A Extended", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(0, 0, 0));
        jButton1.setText("Crear");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel3.setText("Ventana 1");

        jLabel4.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("Ventana 2");

        jLabel5.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 0));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Ventana 3");

        tblVentana1.setBackground(new java.awt.Color(204, 255, 255));
        tblVentana1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tblVentana1);

        tblVentana2.setBackground(new java.awt.Color(204, 255, 255));
        tblVentana2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(tblVentana2);

        tblVentana3.setBackground(new java.awt.Color(204, 255, 255));
        tblVentana3.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane3.setViewportView(tblVentana3);

        jLabel6.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 24)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Atendidos");

        tblSimulacion.setBackground(new java.awt.Color(204, 153, 255));
        tblSimulacion.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane4.setViewportView(tblSimulacion);

        ventana1.setBackground(new java.awt.Color(102, 204, 255));
        ventana1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        ventana1.setForeground(new java.awt.Color(0, 0, 0));
        ventana1.setText("Atender");
        ventana1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ventana1ActionPerformed(evt);
            }
        });

        total.setBackground(new java.awt.Color(0, 204, 255));
        total.setFont(new java.awt.Font("OCR A Extended", 1, 14)); // NOI18N
        total.setForeground(new java.awt.Color(0, 0, 0));
        total.setText("Total atendidos");
        total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                totalActionPerformed(evt);
            }
        });

        ventana2.setBackground(new java.awt.Color(102, 204, 255));
        ventana2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        ventana2.setForeground(new java.awt.Color(0, 0, 0));
        ventana2.setText("Atender");
        ventana2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ventana2ActionPerformed(evt);
            }
        });

        ventana3.setBackground(new java.awt.Color(102, 204, 255));
        ventana3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        ventana3.setForeground(new java.awt.Color(0, 0, 0));
        ventana3.setText("Atender");
        ventana3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ventana3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(ventana1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(jPanel1Layout.createSequentialGroup()
                                                .addGap(55, 55, 55)
                                                .addComponent(ventana2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(91, 91, 91))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(87, 87, 87)))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addComponent(ventana3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(14, 14, 14))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(28, 28, 28))))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGap(26, 26, 26)
                                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(39, 39, 39)
                                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 373, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(total)))
                        .addContainerGap())
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtTramites, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1)
                        .addGap(675, 675, 675)
                        .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtTramites, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jButton1))
                        .addGap(22, 22, 22))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 225, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(ventana1)
                            .addComponent(ventana2)
                            .addComponent(ventana3))
                        .addGap(259, 259, 259))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(total)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 25, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        if (txtTramites.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Falta numero");
        } 
        else {
            try {
                CargarPrimerTabla();
                CargarSegunda();
                CargarTercer();
            } 
            catch (Exception e) {
                
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void ventana1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ventana1ActionPerformed
        // TODO add your handling code here:
        try {
            Guardar();
            Ventanilla1();
            CargarSimulacion();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_ventana1ActionPerformed

    private void totalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_totalActionPerformed
        // TODO add your handling code here:
        Integer IdPersona = simulacionDao.getListaSimulacion().getLongitud();
        JOptionPane.showMessageDialog(null, "Personas atendidas en el proceso : "+IdPersona+"\nTiempo total : "+mts.sumarColumna(2)+" minutos");
    }//GEN-LAST:event_totalActionPerformed

    private void ventana2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ventana2ActionPerformed
        // TODO add your handling code here:
        try {
            Guardar2();
            Ventanilla2();
            CargarSimulacion();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_ventana2ActionPerformed

    private void ventana3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ventana3ActionPerformed
        // TODO add your handling code here:
        try {
            Guardar3();
            Ventanilla3();
            CargarSimulacion();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_ventana3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FrmSimulacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FrmSimulacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FrmSimulacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FrmSimulacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FrmSimulacion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTable tblSimulacion;
    private javax.swing.JTable tblVentana1;
    private javax.swing.JTable tblVentana2;
    private javax.swing.JTable tblVentana3;
    private javax.swing.JButton total;
    private javax.swing.JTextField txtTramites;
    private javax.swing.JButton ventana1;
    private javax.swing.JButton ventana2;
    private javax.swing.JButton ventana3;
    // End of variables declaration//GEN-END:variables
}
