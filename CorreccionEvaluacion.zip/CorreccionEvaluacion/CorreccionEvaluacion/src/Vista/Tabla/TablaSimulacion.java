/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista.Tabla;

import Controlador.TDA.ListaDinamica.ListaDinamica;
import Controlador.Tda.listas.Exepciones.ListaVacia;
import Modelo.Tramite;
import Modelo.Simulacion;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Alexander
 */
public class TablaSimulacion extends AbstractTableModel {

    private ListaDinamica<Simulacion> personasTabla;

    public ListaDinamica<Simulacion> getPersonasTabla() {
        return personasTabla;
    }

    public void setPersonasTabla(ListaDinamica<Simulacion> personasTabla) {
        this.personasTabla = personasTabla;
    }
    
    @Override
    public int getRowCount() {
        return personasTabla.getLongitud();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }
    
    @Override
    public Object getValueAt(int Fila, int Columna) {

        try {
            Simulacion p = personasTabla.getInfo(Fila);
            
            switch (Columna) {
                case 0:
                    return (p != null) ? Fila+1: "";
                case 1:
                    return (p != null) ? p.getNumeroPersonas(): "";
                case 2:
                    return (p != null) ? p.getTiempoFinal(): "";
                
                default:
                    return null;
            }
        } 
        catch (ListaVacia | IndexOutOfBoundsException ex) {
            
        }
        return personasTabla;
    }


    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Id persona";
            case 1:
                return "Numero Personas";
            case 2:
                return "Tiempo";
            
            default:
                return null;
        }
    }
    
    public int sumarColumna(int columna) {
        double suma = 0.0;

        for (int fila = 0; fila < getRowCount(); fila++) {
            try {
                Object valor = getValueAt(fila, columna);

                if (valor instanceof Number) {
                    suma += ((Number) valor).doubleValue();
                }
            } 
            catch (Exception e) {
            }
        }

        return (int) suma;
    }
}
