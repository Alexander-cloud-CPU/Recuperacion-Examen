/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista.Tabla;

import Controlador.TDA.ListaDinamica.ListaDinamica;
import Controlador.Tda.listas.Exepciones.ListaVacia;
import Modelo.Tramite;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author Alexander
 */
public class ModeloTabla1 extends AbstractTableModel {

    private ListaDinamica<Tramite> personasTabla;

    public ListaDinamica<Tramite> getPersonasTabla() {
        return personasTabla;
    }

    public void setPersonasTabla(ListaDinamica<Tramite> personasTabla) {
        this.personasTabla = personasTabla;
    }
    
    @Override
    public int getRowCount() {
        return personasTabla.getLongitud();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }
    
    @Override
    public Object getValueAt(int Fila, int Columna) {

        try {
            Tramite p = personasTabla.getInfo(Fila);
            
            switch (Columna) {
                case 0:
                    return (p != null) ? Fila+1: "";
                case 1:
                    return (p != null) ? p.getNombre() : "";
                case 2:
                    return (p != null) ? p.getDuracion(): "";
                
                default:
                    return null;
            }
        } 
        catch (ListaVacia | IndexOutOfBoundsException ex) {
            
        }
        return personasTabla;
    }


    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Id persona";
            case 1:
                return "Nombre";
            case 2:
                return "Duracion";
            
            default:
                return null;
        }
    }
    
    public int sumarColumna(int columna) {
        int suma = 0;

        for (int fila = 0; fila < getRowCount(); fila++) {
            try {
                Object valor = getValueAt(fila, columna);

                if (valor instanceof Number) {
                    suma += ((Number) valor).doubleValue();
                }
            } 
            catch (Exception e) {
            }
        }

        return suma;
    }
}
