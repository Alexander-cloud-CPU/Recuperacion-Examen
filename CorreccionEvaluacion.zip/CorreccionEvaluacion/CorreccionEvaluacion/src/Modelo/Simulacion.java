/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import Controlador.TDA.ListaDinamica.ListaDinamica;
import Controlador.Tda.Colas.QueueUltimate;

/**
 *
 * @author Alexander
 */
public class Simulacion {
    private Integer id;
    private Integer NumeroPersonas;
    private Integer TiempoFinal;
    private ListaDinamica<QueueUltimate<Tramite>> ventanilla = new ListaDinamica<>();
    private Tramite persona;

    
    
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNumeroPersonas() {
        return NumeroPersonas;
    }

    public void setNumeroPersonas(Integer NumeroPersonas) {
        this.NumeroPersonas = NumeroPersonas;
    }

    public Integer getTiempoFinal() {
        return TiempoFinal;
    }

    public void setTiempoFinal(Integer TiempoFinal) {
        this.TiempoFinal = TiempoFinal;
    }

    public Tramite getPersona() {
        return persona;
    }

    public void setPersona(Tramite persona) {
        this.persona = persona;
    }
    
    public Simulacion() {
        
    }

    public Simulacion(Integer id, Integer NumeroPersonas, Integer TiempoFinal, Tramite persona) {
        this.id = id;
        this.NumeroPersonas = NumeroPersonas;
        this.TiempoFinal = TiempoFinal;
        this.persona = persona;
    }
    
}
