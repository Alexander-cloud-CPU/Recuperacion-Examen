/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Alexander
 */
public class Tramite {
    private Integer idTramite;
    private String Nombre;
    private Integer Duracion;

    
    
    public Integer getIdPersona() {
        return idTramite;
    }

    public void setIdPersona(Integer idPersona) {
        this.idTramite = idPersona;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public Integer getDuracion() {
        return Duracion;
    }

    public void setDuracion(Integer Duracion) {
        this.Duracion = Duracion;
    }
    
    public Tramite() {
        
    }

    public Tramite(Integer idPersona, String Nombre, Integer Duracion) {
        this.idTramite = idPersona;
        this.Nombre = Nombre;
        this.Duracion = Duracion;
    }

    @Override
    public String toString() {
        return "idPersona=" + idTramite + ", Nombre=" + Nombre + ", Duracion=" + Duracion + "\n";
    }
    
}
